let backgrounds = ["https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=0444373dd059057834eff6e6a3e5eaa7&auto=format", "https://images.unsplash.com/photo-1462826303086-329426d1aef5?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=4a6ba9edd5cbfe2c9ed4cf4c4c2a8bb0&auto=format", "https://images.unsplash.com/photo-1431540015161-0bf868a2d407?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=d5c6c65f9940b030316c3cdf11b16659&auto=format"];

$('#main-container').delay(1000).fadeIn(500, animateBackground());

function animateBackground() {

    window.setTimeout(function(){

        let url = backgrounds[backgrounds.push(backgrounds.shift()) - 1];

        $('#main-container').delay(10000).fadeOut(1000, function(){

            $(this).css("background-image", "url(" + url + ")")

        }).fadeIn(1000, animateBackground())

    });
}
window.onload = animateBackground();